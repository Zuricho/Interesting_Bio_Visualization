Changes to matplotlib to allow for line width in hatching pattern to be updated. Hopefully
this will be updated to an option in a newer version.
