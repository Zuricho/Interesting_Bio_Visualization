# Input BED

<img src="input_bed.png" width="400px"/>

Example showing how to load BED profile information and plot against a design.
