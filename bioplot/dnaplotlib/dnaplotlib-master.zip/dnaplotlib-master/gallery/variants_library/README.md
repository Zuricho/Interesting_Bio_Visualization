# Library of Design Variants

<img src="variants_library.png" width="400px"/>

Library of refactored nitrogen fixation clusters variants where order, orientation and expression has been varied. This is generated using the plot_SBOL_designs.py application.
