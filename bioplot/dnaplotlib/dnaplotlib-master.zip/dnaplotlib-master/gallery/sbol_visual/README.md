# SBOL Visual

<img src="sbol_visual.png" width="400px"/>

Example that loads an SBOL file and uses the SBOL integration in DNAplotlib to plot the main design.
