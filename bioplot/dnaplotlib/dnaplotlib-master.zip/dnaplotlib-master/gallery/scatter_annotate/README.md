# Annotated Scatter

<img src="scatter_annotate.png" width="400px"/>

Example showing how to annotate an existing matplotlib figure with genetic designs.

