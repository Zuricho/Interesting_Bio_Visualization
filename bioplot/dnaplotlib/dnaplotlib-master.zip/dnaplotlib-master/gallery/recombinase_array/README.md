# Recombinase Memory Array

<img src="recombinase_array.png" width="400px"/>

Recombination sites are not built-in to DNAplotlib and so this example shows how to add user-defined parts and regulation associated with them.
