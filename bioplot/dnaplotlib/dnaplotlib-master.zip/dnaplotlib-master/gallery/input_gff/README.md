# Input GFF

<img src="input_gff.png" width="400px"/>

Example showing how to load designs from GFF files
