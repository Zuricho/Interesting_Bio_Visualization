# Annotate Design

<img src="annotate_design.png" width="400px"/>

Example showing the ability anotate designs with additional information.
