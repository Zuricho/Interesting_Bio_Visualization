# Recombinase NOT-gate

<img src="recombinase_not_gate.png" width="400px"/>

Recombination sites are not built-in to DNAplotlib and so this example shows how to add user-defined parts and regulation associated with them. The plot illustrates their use in a reversible NOT-gate.
