# Sequence Features

<img src="sequence_features.png" width="400px"/>

Example showing how to design annotations for a sequence. This functionality will eventually be integrated into the library.
