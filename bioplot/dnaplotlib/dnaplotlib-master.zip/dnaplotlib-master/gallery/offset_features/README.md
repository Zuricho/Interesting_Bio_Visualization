# Offset multiple features

<img src="offset_features_y_offset.png" width="400px"/>

This example hows how designs where multiple overlapping features can be plotted. Two approaches are included: (i) use of alternative axes as tracks for each frame of interest, and (ii) use of the y_offset option to position some features away from the main plotting backbone.
