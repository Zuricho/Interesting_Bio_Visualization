# SBOL Visual Parts & Customization

<img src="all_parts.png" width="600px"/>

Illustration of all SBOL Visual parts in forward and reverse direction. Each part can have its apperance customised to convay further information.

