# XNOR Truthtable 

<img src="xnor_truthtable.png" width="400px"/>

Example showing how to annotate an existing matplotlib figure with genetic designs. The plot shows predicted output for the repressor-based genetic logic circuit.
